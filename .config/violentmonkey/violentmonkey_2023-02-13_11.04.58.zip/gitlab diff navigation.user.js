// ==UserScript==
// @name        gitlab diff navigation
// @namespace   Violentmonkey Scripts
// @match       https://gitlab.eb-tools.com/engineering/cem-digital/xmatters/apps/*/-/merge_requests/*
// @grant       none
// @version     1.0
// @author      -
// @description 11/10/2022, 10:02:10 AM
// ==/UserScript==

function nextDiffPage() {
  const button = document.querySelector("[aria-label='Go to next page']");
  if (button) {
    button.click();
  }
}

function prevDiffPage() {
  const button = document.querySelector("[aria-label='Go to previous page']");
    if (button) {
    button.click();
  }
}

document.addEventListener("keydown", event => {
  if (event.metaKey === true && event.code === "KeyJ") {
    return nextDiffPage();
  }

  if (event.metaKey === true && event.code === "KeyK") {
    return prevDiffPage();
  }
});