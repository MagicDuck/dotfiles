// ==UserScript==
// @name        gitlab Deploy button
// @namespace   Violentmonkey Scripts
// @match       https://gitlab.eb-tools.com/engineering/cem-digital/xmatters/apps/*/-/merge_requests/*
// @grant       none
// @version     1.0
// @author      -
// @description 11/9/2022, 2:23:54 PM
// ==/UserScript==

// logic ------------------------------------------------------------------------------------------------------------------
function handleDeploy() {
  const [path, project, mrId] = location.pathname.match(/.*\/([^\/]+)\/\-\/merge_requests\/([0-9]+)/);
  const branchName = getBranchName();
  const deployURL = getDeployURL({project, mrId, branchName});
  window.open(deployURL)
}

const deployUrlHandlers = {};
function getDeployURL({project, mrId, branchName}) {
  const handler = deployUrlHandlers[project];
  if (handler) {
    return handler({mrId, branchName})
  } else {
    window.alert(`No deploy url handler defined for project "${project}". Please define one in the user script.`)
  }
}

function addDeploymentUrlHandler(project, handler) {
  deployUrlHandlers[project] = handler;
}

function getBranchName() {
  let branchName = document.querySelector("[aria-label='Copy branch name']").getAttribute("data-clipboard-text");
  try {
    branchName = JSON.parse(branchName).text
  } catch (e) {
  }

  return branchName;
}

function createDeployButton() {
  const button = document.createElement("button");
  button.textContent = "Deploy";
  button.style.boxShadow = "inset 0 0 0 1px #ab6100";
  "gl-display-none gl-md-display-block btn gl-button btn-default btn-grouped".split(" ").forEach(className => button.classList.add(className));
  button.onclick = handleDeploy;
  return button;
}

function getDeployVersion({branchName, suffix, fallbackVersion}) {
  const [_, prefix, number] = branchName.match(/(\w+)[-](\d+)/);
  if (prefix && number) {
    return `0.x.${prefix.toLowerCase()}${number}${suffix}`
  }

  return fallbackVersion;
}

function getPreId({branchName, fallbackVersion}) {
  const [_, prefix, number] = branchName.match(/(\w+)[-](\d+)/);
  if (prefix && number) {
    return `${prefix.toLowerCase()}-${number}`
  }

  return fallbackVersion;
}

function getTicket(branchName) {
  const [_, ticket] = branchName.match(/(\w+[-]\d+)/);
  return ticket;
}

// main
const buttonsSection = document.querySelector(".merge-request .js-issuable-actions > div");
if (buttonsSection) {
  const deployButton = createDeployButton();
  buttonsSection.append(deployButton);
}


// deployment url handlers for different projects ------------------------------------------------------------------------------------------------------------------

const DEFAULT_HOSTNAME = "stephanbcorp.dev.xmatters.com";
const DEFAULT_SLACK_CHANNEL = "kessel-builds";
const FALLBACK_VERSION = "0-x-sbadragan";
const FALLBACK_TICKET_NAME = "sbadragan";
const DEFAULT_VERSION_SUFFIX = "sb";
const DEFAULT_DB_NAME = "kramerica";

addDeploymentUrlHandler('frontend', ({branchName}) => {
  const params = new URLSearchParams();
  params.append("hostnames", DEFAULT_HOSTNAME);
  params.append("branch", branchName);
  return `https://jenkins.i.xmatters.com/job/frontend/job/frontend-branch-build-and-deploy/parambuild/?${params.toString()}`;
});
addDeploymentUrlHandler('spark', ({branchName}) => {
  const params = new URLSearchParams();
  params.append("preid", getPreId({branchName, fallbackVersion: "cor-xxx"}));
  params.append("semverIncrementLevel", "prepatch");
  params.append("branch", branchName);
  return `https://jenkins.i.xmatters.com/job/frontend/job/spark-test-publish/parambuild/?${params.toString()}`;
});
addDeploymentUrlHandler('ondemand', ({branchName}) => {
  const params = new URLSearchParams();
  params.append("slackChannel", DEFAULT_SLACK_CHANNEL);
  params.append("branch", branchName);
  params.append("version", getDeployVersion({branchName, suffix: DEFAULT_VERSION_SUFFIX, fallbackVersion: FALLBACK_VERSION}));
  return `https://jenkins.i.xmatters.com/job/kessel/job/ondemand/job/webui-branch-deploy-gitlab/parambuild/?${params.toString()}`;
});
addDeploymentUrlHandler('xM-API', ({branchName}) => {
  const params = new URLSearchParams();
  params.append("slackChannel", DEFAULT_SLACK_CHANNEL);
  params.append("branch", branchName);
  params.append("version", getDeployVersion({branchName, suffix: DEFAULT_VERSION_SUFFIX, fallbackVersion: FALLBACK_VERSION}));
  return `https://jenkins.i.xmatters.com/job/kamino/job/xmapi/job/xmapi-branch-build-deploy/parambuild?${params.toString()}`;
});
addDeploymentUrlHandler('xm-database', ({branchName}) => {
  const params = new URLSearchParams();
  params.append("databaseName", DEFAULT_DB_NAME);
  params.append("operation", "migrate");
  params.append("branch", branchName);
  return `https://jenkins.i.xmatters.com/job/xm-database/job/xm-database-service-apply/parambuild/?${params.toString()}`;
});
addDeploymentUrlHandler('hyrax', ({branchName}) => {
  const params = new URLSearchParams();
  params.append("startStage", "build");
  params.append("createPubSubResources", "true");
  params.append("xmApiCompatibility", "0.x.main");
  params.append("slackChannel", DEFAULT_SLACK_CHANNEL);
  params.append("ticket", getTicket(branchName) || FALLBACK_TICKET_NAME);
  params.append("branch", branchName);
  return `https://jenkins.i.xmatters.com/job/mustafar/job/merge-builds/job/hyrax-branch-build-pipeline/parambuild/?${params.toString()}`;
});
